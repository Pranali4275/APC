file = open("student.txt", "w")

file.write("Name: Anagha\n")
file.write("Roll No: 101\n")
file.write("Branch: Computer Engineering\n")
file.write("Semester: 5")

file.close()

print("Student information written successfully.")