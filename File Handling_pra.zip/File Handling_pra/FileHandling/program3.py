file = open("student1.txt", "a")

file.write("College: DYP College\n")
file.write("City: Kolhapur\n")

file.close()

print("Information appended successfully.")