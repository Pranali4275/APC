"""User authentication: signup, login, password hashing and validation.

Uses only the Python standard library (hashlib, secrets, csv, re, os, datetime)
so the project stays 100% Python with no extra dependencies.
"""
import os
import csv
import re
import hashlib
import secrets
from datetime import datetime

USERS_FILE = os.path.join(os.path.dirname(__file__), "data", "users.csv")
USER_FIELDS = ["id", "name", "email", "password_hash", "salt", "created_at"]

# Validation patterns
NAME_RE = re.compile(r"[A-Za-z][A-Za-z .'-]{1,29}")
EMAIL_RE = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")


class AuthError(Exception):
    """Raised when signup or login fails validation."""


# ── Field validators ──────────────────────────────────────────────
def validate_signup_name(name):
    name = str(name).strip()
    if not NAME_RE.fullmatch(name):
        raise AuthError("Name must be 2-30 letters (spaces . ' - allowed).")
    return name


def validate_signup_email(email):
    email = str(email).strip().lower()
    if not EMAIL_RE.match(email):
        raise AuthError("Please enter a valid email address.")
    return email


def validate_signup_password(password, confirm=""):
    """Strong password, checked with regular expressions (one rule per message)."""
    password = str(password)
    rules = [
        (r".{8,}", "Password must be at least 8 characters long."),
        (r"[a-z]", "Password must contain a lowercase letter."),
        (r"[A-Z]", "Password must contain an uppercase letter."),
        (r"\d", "Password must contain a number."),
        (r"[@$!%*?&#_-]", "Password must contain a symbol such as @ $ ! % * ? & #."),
    ]
    for pattern, message in rules:
        if not re.search(pattern, password):
            raise AuthError(message)
    if confirm and password != confirm:
        raise AuthError("Password and confirm password do not match.")
    return password


# ── Password hashing (PBKDF2-SHA256) ──────────────────────────────
def _hash_password(password, salt):
    return hashlib.pbkdf2_hmac("sha256", password.encode(), salt, 100_000).hex()


def _read_users():
    """Return list of dict rows from the users CSV (empty list if missing)."""
    if not os.path.exists(USERS_FILE):
        return []
    with open(USERS_FILE, newline="") as f:
        return list(csv.DictReader(f))


# ── Public API ────────────────────────────────────────────────────
def signup(name, email, password, confirm=""):
    """Register a new user. Returns user dict on success, raises AuthError."""
    name = validate_signup_name(name)
    email = validate_signup_email(email)
    validate_signup_password(password, confirm)

    users = _read_users()
    if any(u["email"] == email for u in users):
        raise AuthError("An account with this email already exists.")

    salt = secrets.token_hex(16)
    user = {
        "id": str(len(users) + 1),
        "name": name,
        "email": email,
        "password_hash": _hash_password(password, bytes.fromhex(salt)),
        "salt": salt,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
    new_file = not os.path.exists(USERS_FILE)
    try:
        with open(USERS_FILE, "a", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=USER_FIELDS)
            if new_file:
                writer.writeheader()
            writer.writerow(user)
    except OSError as err:
        raise AuthError(f"Could not save account: {err}")
    return user


def login(email, password):
    """Authenticate a user. Returns user dict on success, raises AuthError."""
    email = str(email).strip().lower()
    if not email:
        raise AuthError("Please enter your email.")
    if not password:
        raise AuthError("Please enter your password.")

    users = _read_users()
    user = next((u for u in users if u["email"] == email), None)
    if user is None:
        raise AuthError("No account found with this email. Please sign up first.")
    if _hash_password(password, bytes.fromhex(user["salt"])) != user["password_hash"]:
        raise AuthError("Incorrect password. Please try again.")
    return user


def get_user_by_email(email):
    """Return user dict for a given email or None."""
    email = str(email).strip().lower()
    return next((u for u in _read_users() if u["email"] == email), None)
