"""File handling (CSV read/write), exception handling and Pandas statistics.

Every analysis is saved with the logged-in user's email, so each user
sees only his/her own dashboard, progress and charts.
All functions take an optional `user`; user=None means "all records".
"""
import csv, os
from datetime import datetime
import pandas as pd

FILE = os.path.join(os.path.dirname(__file__), "data", "records.csv")
FIELDS = ["date", "name", "age", "gender", "height", "weight", "activity",
          "goal", "bmi", "score", "calories", "user"]
NUMERIC = ["age", "height", "weight", "bmi", "score", "calories"]


# ---------------------------------------------------------------- write
def save_record(record):
    """Append one analysis (with date, time and user) to records.csv."""
    _migrate_if_needed()
    record = dict(record)
    record.setdefault("date", datetime.now().strftime("%Y-%m-%d %H:%M"))
    record.setdefault("user", "")
    new_file = not os.path.exists(FILE)
    try:
        with open(FILE, "a", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS, extrasaction="ignore")
            if new_file:
                writer.writeheader()
            writer.writerow(record)
        return True
    except OSError as err:
        print("Could not save record:", err)
        return False


def _migrate_if_needed():
    """Upgrade an old records.csv (missing date/user columns) to the new format."""
    if not os.path.exists(FILE):
        return
    try:
        with open(FILE, "r", newline="") as f:
            reader = csv.DictReader(f)
            header = reader.fieldnames or []
            if header == FIELDS:
                return
            rows = list(reader)
        with open(FILE, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS, restval="", extrasaction="ignore")
            writer.writeheader()
            writer.writerows(rows)
    except OSError:
        pass


# ----------------------------------------------------------------- read
def load_records(user=None):
    """Return records as a pandas DataFrame (only one user's if `user` is given)."""
    _migrate_if_needed()
    try:
        df = pd.read_csv(FILE)
    except FileNotFoundError:
        df = pd.DataFrame(columns=FIELDS)
    except Exception:
        try:
            df = pd.read_csv(FILE, on_bad_lines="skip")
        except Exception:
            df = pd.DataFrame(columns=FIELDS)
    for col in FIELDS:
        if col not in df.columns:
            df[col] = ""
    for col in NUMERIC:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df["user"] = df["user"].fillna("").astype(str)
    if user is not None:
        df = df[df["user"] == user]
    return df.reset_index(drop=True)


def _parse_dates(series):
    try:
        return pd.to_datetime(series, errors="coerce", format="mixed")
    except (TypeError, ValueError):          # older pandas
        return pd.to_datetime(series, errors="coerce")


def stats(user=None):
    """High-level aggregate statistics."""
    df = load_records(user).dropna(subset=["score", "bmi"])
    if df.empty:
        return {"count": 0}
    return {"count": len(df), "avg_score": round(df["score"].mean(), 2),
            "avg_bmi": round(df["bmi"].mean(), 1),
            "score_by_goal": df.groupby("goal")["score"].mean().round(2).to_dict()}


def latest_metrics(user=None):
    """The most recent analysis (used by the dashboard cards)."""
    df = load_records(user)
    if df.empty:
        return None
    row = df.iloc[-1]
    return {"date": str(row["date"]), "bmi": float(row["bmi"]), "score": float(row["score"]),
            "calories": float(row["calories"]), "weight": float(row["weight"]),
            "name": str(row["name"]), "goal": str(row["goal"])}


def entries(user=None, limit=None):
    """Every analysis as a dict, oldest first. Keys use the same 'avg_' names as
    monthly_progress() so the same charts/JS can show either one."""
    df = load_records(user)
    if df.empty:
        return []
    dates = _parse_dates(df["date"])
    out = []
    for i, row in df.iterrows():
        dt = dates.iloc[i]
        ok = not pd.isna(dt)
        out.append({
            "date": dt.strftime("%d %b %Y, %H:%M") if ok else "-",
            "tick": dt.strftime("%d %b\n%H:%M") if ok else f"#{i + 1}",
            "name": str(row["name"]),
            "avg_bmi": round(float(row["bmi"]), 1),
            "avg_score": round(float(row["score"]), 1),
            "avg_calories": round(float(row["calories"])),
            "avg_weight": round(float(row["weight"]), 1),
        })
    return out[-limit:] if limit else out


def monthly_progress(user=None):
    """Group one user's records by month and return monthly averages."""
    df = load_records(user)
    if df.empty:
        return []
    df["date"] = _parse_dates(df["date"])
    df = df.dropna(subset=["date"])
    if df.empty:
        return []
    df["month"] = df["date"].dt.to_period("M").astype(str)
    result = []
    for month, grp in df.groupby("month"):
        result.append({
            "month": month, "records": len(grp),
            "avg_bmi": round(float(grp["bmi"].mean()), 1),
            "avg_score": round(float(grp["score"].mean()), 1),
            "avg_calories": round(float(grp["calories"].mean())),
            "avg_weight": round(float(grp["weight"].mean()), 1),
            "max_score": round(float(grp["score"].max()), 1),
            "min_weight": round(float(grp["weight"].min()), 1),
        })
    return sorted(result, key=lambda x: x["month"])


def clear_records(user=None):
    """Delete records: one user's (user given) or everything (header is kept)."""
    if user is None:
        keep = load_records().iloc[0:0]
    else:
        df = load_records()
        keep = df[df["user"] != user]
    keep[FIELDS].to_csv(FILE, index=False)
