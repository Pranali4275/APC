"""Matplotlib charts: one point per analysis, drawn only for the given user."""
import io
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from storage import entries

COLORS = {"bmi": "#0d9488", "score": "#16a34a", "calories": "#f59e0b", "weight": "#8b5cf6"}
TITLES = {"bmi": "BMI", "score": "Health Score", "calories": "Daily Calories", "weight": "Weight (kg)"}
MAX_POINTS = 12                         # show the latest 12 analyses


def _fig_to_png(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=100, facecolor="white")
    plt.close(fig)
    return buf.getvalue()


def _empty(ax, msg="No data yet. Run a health analysis to start tracking."):
    ax.text(0.5, 0.5, msg, ha="center", va="center", fontsize=11, color="#999",
            transform=ax.transAxes, wrap=True)
    ax.set_xticks([]); ax.set_yticks([])
    for s in ax.spines.values():
        s.set_visible(False)


def _plot(ax, ents, key, kind="line", title=None, ylim=None):
    """Draw one metric. kind = 'line' or 'bar'."""
    color = COLORS[key]
    xs = list(range(len(ents)))
    vals = [e["avg_" + key] for e in ents]
    if kind == "bar":
        ax.bar(xs, vals, color=color, alpha=0.85, width=0.55)
    else:
        ax.plot(xs, vals, marker="o", color=color, linewidth=2.4, markersize=7)
        ax.fill_between(xs, vals, min(vals) - (max(vals) - min(vals) or 1), alpha=0.10, color=color)
    for x, v in zip(xs, vals):
        ax.annotate(f"{v:g}", (x, v), textcoords="offset points", xytext=(0, 9),
                    ha="center", fontsize=8, fontweight="bold", color="#333")
    ax.set_xticks(xs)
    ax.set_xticklabels([e["tick"] for e in ents], fontsize=7.5)
    ax.set_xlim(-0.6, max(len(xs) - 1, 0) + 0.6)
    if ylim:
        ax.set_ylim(*ylim)
    else:
        lo, hi = min(vals), max(vals)
        if kind == "bar":
            ax.set_ylim(0, hi * 1.18)               # head-room for the value labels
        else:
            pad = (hi - lo) * 0.3 or max(abs(hi) * 0.08, 1)
            ax.set_ylim(lo - pad, hi + pad * 1.6)
    ax.set_title(title or TITLES[key], fontsize=11, fontweight="bold", color="#14532d")
    ax.grid(True, axis="y", alpha=0.25)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    if len(ents) == 1:
        ax.text(0.5, 0.04, "Add more analyses to see a trend", transform=ax.transAxes,
                ha="center", fontsize=8, color="#888")


def history_chart(user=None):
    """Simple 2-panel chart: weight and health score for every entry."""
    ents = entries(user, MAX_POINTS)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9, 3.5))
    if ents:
        _plot(ax1, ents, "weight")
        _plot(ax2, ents, "score", kind="bar", ylim=(0, 105))
    else:
        _empty(ax1); _empty(ax2)
    fig.tight_layout()
    return _fig_to_png(fig)


def dashboard_chart(user=None):
    """Compact chart for the dashboard: health score and weight."""
    ents = entries(user, MAX_POINTS)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(8, 3.2))
    if ents:
        _plot(ax1, ents, "score", ylim=(0, 105))
        _plot(ax2, ents, "weight")
    else:
        _empty(ax1); _empty(ax2)
    fig.tight_layout()
    return _fig_to_png(fig)


def progress_chart_all(user=None):
    """2x2 grid: BMI, health score, calories and weight."""
    ents = entries(user, MAX_POINTS)
    fig, axes = plt.subplots(2, 2, figsize=(10, 7))
    (a1, a2), (a3, a4) = axes
    if ents:
        _plot(a1, ents, "bmi", title="BMI Trend")
        _plot(a2, ents, "score", title="Health Score Trend", ylim=(0, 105))
        _plot(a3, ents, "calories", kind="bar", title="Daily Calories")
        _plot(a4, ents, "weight", title="Weight Trend")
    else:
        for ax in (a1, a2, a3, a4):
            _empty(ax)
    fig.tight_layout(pad=2)
    return _fig_to_png(fig)


def progress_chart_metric(metric, user=None):
    """One large chart for one metric: bmi, score, calories or weight."""
    ents = entries(user, MAX_POINTS)
    fig, ax = plt.subplots(figsize=(8, 4.2))
    if ents:
        _plot(ax, ents, metric, kind="bar" if metric == "calories" else "line",
              title=f"{TITLES[metric]} Progress", ylim=(0, 105) if metric == "score" else None)
    else:
        _empty(ax)
    fig.tight_layout()
    return _fig_to_png(fig)
