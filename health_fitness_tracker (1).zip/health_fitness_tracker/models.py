"""OOP: classes, constructors, inheritance and polymorphism."""
from health_utils import calc_bmi

class Person:
    def __init__(self, name, age, gender, height, weight, activity):
        self.name, self.age, self.gender = name, age, gender
        self.height, self.weight, self.activity = height, weight, activity

    @property
    def bmi(self):
        return calc_bmi(self.height, self.weight)

class Plan:
    """Base class: every plan has a calorie target and advice."""
    goal = "maintain"
    adjustment = 0

    def __init__(self, person, calories):
        self.person, self.calories = person, calories

    def target_calories(self):
        return self.calories + self.adjustment

    def advice(self):
        return "Keep your current routine and eat balanced meals."

    def summary(self):
        return {"goal": self.goal, "target_calories": self.target_calories(), "advice": self.advice()}

class WeightLossPlan(Plan):
    goal, adjustment = "lose", -500
    def advice(self):
        return "Eat in a small deficit, walk daily and add 3 cardio sessions a week."

class MuscleGainPlan(Plan):
    goal, adjustment = "gain", 300
    def advice(self):
        return "Eat extra protein, lift weights 4 days a week and sleep 7-8 hours."

PLANS = {"lose": WeightLossPlan, "gain": MuscleGainPlan, "maintain": Plan}

def make_plan(goal, person, calories):
    return PLANS[goal](person, calories)
