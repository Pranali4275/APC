# Health Pro – Smart Health & Fitness Tracker – Project Guide (Flask only)

## 1. Languages
| Language | Kuthe |
|---|---|
| Python | backend: app.py, auth.py, storage.py, model.py, charts.py, models.py, health_utils.py, utils_pkg/ |
| HTML (Jinja2 templates) | templates/*.html |
| CSS | templates/base.html madhe `<style>` |
| JavaScript | templates/*.html madhe `<script>` (fetch API, form validation, UI) |
| CSV / TXT | data/*.csv (database), reports/*.txt |

## 2. Backend vs Frontend
**Backend (Python + Flask):** app.py (routes/API), auth.py (login/signup), storage.py (records), model.py (ML), charts.py (Matplotlib PNG), health_utils.py (validation + formulas), models.py (OOP plans), utils_pkg/.
**Frontend:** templates/ – base.html (sidebar, login modal, CSS), landing.html, dashboard.html, analyzer.html, progress.html, history.html.
Frontend -> `fetch()` -> Flask route -> JSON/PNG -> frontend dakhavto.

## 3. Python concepts – kuthe use kele
| Concept | File / function |
|---|---|
| Variables, data types, operators, if/else, loops | sarvatra |
| Functions | health_utils.py (calc_bmi, calc_bmr, validate_inputs) |
| Lambda | utils_pkg/text_tools.py `newest_first`; storage.py sort key |
| List / Dict | app.py JSON dicts, storage.py entries() |
| Tuple | text_tools.py `BMI_BANDS`; health_utils.py GENDERS, ACTIVITIES, GOALS |
| Set | text_tools.py `health_tips()` (union `|=`, difference `-=`) |
| String methods | text_tools.py `clean_name()` (strip, split, capitalize, join) |
| array module | text_tools.py `bmi_history_array()` |
| File handling | storage.py, auth.py (csv), utils_pkg/report.py (txt) |
| Directory handling | utils_pkg/report.py (os.makedirs, os.listdir, os.path) |
| Modules & packages | utils_pkg/ package + auth, storage, charts, model modules |
| Exception handling | AuthError, ValidationError; try/except in storage.py, auth.py |
| Regular expressions | auth.py, health_utils.py, utils_pkg/report.py |
| OOP (class, constructor, inheritance, polymorphism) | models.py: Person, Plan, WeightLossPlan, MuscleGainPlan, make_plan() |
| Decorator | app.py `login_required`, `page_login_required` |
| NumPy | generate_data.py (synthetic dataset) |
| Pandas | storage.py, model.py |
| Matplotlib | charts.py |
| scikit-learn | model.py (LinearRegression, train_test_split, r2_score, LabelEncoder) |
| Flask | app.py |
| hashlib / secrets | auth.py (PBKDF2 password hash + salt) |

## 4. Validation – kuthe kuthe
| Kay validate hote | Kuthe | Kase |
|---|---|---|
| Name (2-30 letters) | auth.py `validate_signup_name`, health_utils.py `validate_name` | regex `[A-Za-z][A-Za-z .'-]{1,29}` |
| Email | auth.py `validate_signup_email` | regex EMAIL_RE |
| Strong password (8+, lower, upper, digit, symbol, match confirm) | auth.py `validate_signup_password` | 5 regex rules |
| Login (empty email/password, wrong user/password) | auth.py `login` | if checks + AuthError |
| Duplicate email | auth.py `signup` | any() check |
| Age 10-100, height 100-250, weight 25-300, gender/activity/goal | health_utils.py `validate_inputs` | range checks + tuple membership, ValidationError |
| Report download only own file | utils_pkg/report.py `is_report_of` | regex fullmatch (403 otherwise) |
| Login required for API | app.py `login_required` | decorator, 401 |
| Chart metric valid | app.py `chart_progress_metric` | whitelist (bmi/score/calories/weight) |
| Frontend (browser) checks | base.html (name maxlength 30), analyzer.html (min/max, all fields filled) | HTML attributes + JavaScript |
Server-side validation (Python) khari security aahe; JS validation fakt user-friendly aahe.

## 5. Flask routes (app.py)
Pages: `/`, `/dashboard`, `/analyzer`, `/history`, `/progress`
Auth: POST `/signup`, `/login`, `/logout`, GET `/session`
Core: POST `/predict`; GET `/api/dashboard`, `/api/progress`, `/api/history`, `/history.csv`, `/reports/<file>`, `/stats`
Charts: `/chart/dashboard.png`, `/chart/progress.png`, `/chart/<metric>.png`, `/chart.png`

## 6. Run
```
pip install -r requirements.txt
python app.py        # http://127.0.0.1:5000
```
