"""Unit 2: file + directory handling.
Every analysis is also saved as a readable TXT report inside the reports/ folder."""
import os
import re
from datetime import datetime

REPORT_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "reports")


def user_slug(email):
    """'anu.k@gmail.com' -> 'anu_k_gmail_com' (safe to use in a file name)."""
    return re.sub(r"[^A-Za-z0-9]+", "_", str(email).strip().lower()).strip("_")


def is_report_of(email, filename):
    """True only if `filename` is a report that belongs to this user."""
    return re.fullmatch(re.escape(user_slug(email)) + r"_\d{8}_\d{6}(_\d+)?\.txt", filename) is not None


def save_report(email, result):
    """Create reports/ if needed and write one TXT report. Returns the file name."""
    os.makedirs(REPORT_DIR, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    name = f"{user_slug(email)}_{stamp}.txt"
    n = 1
    while os.path.exists(os.path.join(REPORT_DIR, name)):      # two analyses in the same second
        n += 1
        name = f"{user_slug(email)}_{stamp}_{n}.txt"
    with open(os.path.join(REPORT_DIR, name), "w", encoding="utf-8") as f:
        f.write("HEALTH PRO - PERSONAL HEALTH REPORT\n")
        f.write("=" * 36 + "\n")
        f.write("Generated: " + datetime.now().strftime("%d %b %Y, %H:%M") + "\n\n")
        for key, value in result.items():
            f.write(f"{key.replace('_', ' ').title():<20}: {value}\n")
    return name


def list_reports(email):
    """Newest first, only this user's reports."""
    if not os.path.isdir(REPORT_DIR):
        return []
    return sorted((f for f in os.listdir(REPORT_DIR) if is_report_of(email, f)), reverse=True)


def report_path(filename):
    return os.path.join(REPORT_DIR, filename)
