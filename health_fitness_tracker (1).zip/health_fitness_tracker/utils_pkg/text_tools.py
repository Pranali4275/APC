"""Unit 1 concepts: strings, tuples, sets, arrays, lambda."""
from array import array


def clean_name(name):
    """String methods: strip, split, capitalize, join.  '  amit   PATIL ' -> 'Amit Patil'"""
    return " ".join(word.capitalize() for word in str(name).strip().split())


# Tuple (immutable): (upper limit, label) for every BMI band
BMI_BANDS = ((18.5, "Underweight"), (25, "Normal weight"), (30, "Overweight"), (float("inf"), "Obese"))


def bmi_category(bmi):
    return next(label for limit, label in BMI_BANDS if bmi < limit)


def health_tips(bmi, activity, goal="maintain", water=2.5):
    """Sets: collect unique tips, then use union (|=) and difference (-=)."""
    tips = {f"Drink about {water} L of water every day",
            "Sleep 7-8 hours every night",
            "Add a protein source to every meal"}
    if bmi >= 25:
        tips |= {"Cut down sugary drinks and fried food", "Walk briskly for 30 minutes daily"}
    elif bmi < 18.5:
        tips |= {"Add nuts, banana and milk for extra calories", "Eat 5 smaller meals instead of 3 big ones"}
    else:
        tips.add("Your BMI is healthy - keep your routine steady")
    if activity in ("sedentary", "light"):
        tips |= {"Aim for 7,000 steps a day", "Stand up and stretch every hour"}
    tips |= {"lose": {"Eat slowly and stop at 80% full"},
             "gain": {"Lift weights 3-4 days a week and rest well"},
             "maintain": set()}.get(goal, set())
    if activity in ("very", "extra"):
        tips -= {"Walk briskly for 30 minutes daily"}      # already very active
    return sorted(tips)


def bmi_history_array(values):
    """array module: typed array of BMI values (typecode 'f' = float)."""
    return array("f", [float(v) for v in values])


# lambda example: newest first
newest_first = lambda rows: sorted(rows, key=lambda r: str(r.get("date", "")), reverse=True)
