"""Data helpers used by the Flask app (landing page, history page)."""
import csv, io
import storage, auth
from .report import list_reports
from .text_tools import newest_first


def landing_context():
    """Real numbers for the landing page."""
    return {"users": len(auth._read_users()),
            "analyses": storage.stats().get("count", 0)}


def history_data(email):
    """One user's records (newest first) and report file names."""
    df = storage.load_records(email).fillna("")
    rows = []
    for r in df.to_dict("records"):
        rows.append({"date": r["date"] or "-", "name": r["name"], "age": r["age"], "gender": r["gender"],
                     "height": r["height"], "weight": r["weight"], "goal": r["goal"],
                     "bmi": r["bmi"], "score": r["score"], "calories": r["calories"]})
    return {"records": newest_first(rows), "reports": list_reports(email)}


def records_csv(email):
    """The user's own records as CSV text (for the 'Download my data' button)."""
    df = storage.load_records(email).drop(columns=["user"])
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    return buf.getvalue()
