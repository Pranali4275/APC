"""NumPy: generate a synthetic training dataset (health_ml_data.csv)."""
import numpy as np
import pandas as pd

rng = np.random.default_rng(42)
N = 300
levels = ["sedentary", "light", "moderate", "very", "extra"]
factor = np.array([1.2, 1.375, 1.55, 1.725, 1.9])

age = rng.integers(18, 65, N)
gender = rng.choice(["male", "female"], N)
height = np.where(gender == "male", rng.normal(173, 7, N), rng.normal(160, 6, N)).round()
bmi = rng.normal(22, 3.5, N)
weight = (bmi * (height / 100) ** 2).round()
idx = rng.integers(0, 5, N)

bmr = 10 * weight + 6.25 * height - 5 * age + np.where(gender == "male", 5, -161)
calories = (bmr * factor[idx] + rng.normal(0, 60, N)).round()
score = np.clip(85 - 2.5 * np.abs(bmi - 22) - 0.2 * (age - 25) + 4 * idx + rng.normal(0, 2, N), 30, 100).round()

df = pd.DataFrame({"Age": age, "Gender": gender, "Height_cm": height.astype(int),
                   "Weight_kg": weight.astype(int), "Activity": np.array(levels)[idx],
                   "HealthScore": score.astype(int), "Calories": calories.astype(int)})
df.to_csv("data/health_ml_data.csv", index=False)
print("Saved", df.shape, "rows to data/health_ml_data.csv")
