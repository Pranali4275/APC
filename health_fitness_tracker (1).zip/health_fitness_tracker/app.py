"""Flask web app: multi-page dashboard + health analysis + auth.

Pages:
  GET  /              redirect to dashboard (or landing if not logged in)
  GET  /dashboard     overview with metric cards + mini charts
  GET  /analyzer      health analysis form + results
  GET  /progress     monthly progress charts

API:
  POST /signup        register
  POST /login         login
  POST /logout        logout
  GET  /session        check login status
  POST /predict       ML health prediction (login required)
  GET  /api/dashboard dashboard data (latest metrics + stats)
  GET  /api/progress  monthly progress data
  GET  /stats         record stats + model R2
  GET  /chart/dashboard.png   dashboard mini chart
  GET  /chart/progress.png    full 4-panel progress chart
  GET  /chart/<metric>.png    single metric trend chart
"""
import os
from functools import wraps

from flask import Flask, render_template, request, jsonify, Response, session, redirect, url_for, send_file, abort
from model import predict_health, metrics
from health_utils import validate_inputs, ValidationError, calc_bmr
from models import Person, make_plan
import storage, charts, auth
from utils_pkg import clean_name, bmi_category, health_tips, save_report, is_report_of, report_path
from utils_pkg.site import landing_context, history_data, records_csv

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "health-pro-dev-secret-key-change-in-prod")


# ── Auth helpers ──────────────────────────────────────────────────
def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_email" not in session:
            return jsonify({"error": "Please login to continue."}), 401
        return fn(*args, **kwargs)
    return wrapper


def page_login_required(fn):
    """Redirect to dashboard (which shows login modal) if not logged in."""
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_email" not in session:
            return redirect(url_for("dashboard"))
        return fn(*args, **kwargs)
    return wrapper


# ── Pages ─────────────────────────────────────────────────────────
@app.route("/")
def home():
    if "user_email" in session:                       # logged in -> straight to the dashboard
        return redirect(url_for("dashboard"))
    return render_template("landing.html", **landing_context())


@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")


@app.route("/analyzer")
def analyzer():
    return render_template("analyzer.html")


@app.route("/history")
def history_page():
    return render_template("history.html")


@app.route("/progress")
def progress():
    return render_template("progress.html")


# ── Auth routes ───────────────────────────────────────────────────
@app.route("/signup", methods=["POST"])
def signup():
    data = request.json or {}
    try:
        user = auth.signup(
            data.get("name", ""), data.get("email", ""),
            data.get("password", ""), data.get("confirm", ""),
        )
    except auth.AuthError as err:
        return jsonify({"error": str(err)}), 400
    session["user_email"] = user["email"]
    session["user_name"] = user["name"]
    return jsonify({"name": user["name"], "email": user["email"]})


@app.route("/login", methods=["POST"])
def login():
    data = request.json or {}
    try:
        user = auth.login(data.get("email", ""), data.get("password", ""))
    except auth.AuthError as err:
        return jsonify({"error": str(err)}), 400
    session["user_email"] = user["email"]
    session["user_name"] = user["name"]
    return jsonify({"name": user["name"], "email": user["email"]})


@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify({"ok": True})


@app.route("/session")
def check_session():
    if "user_email" in session:
        return jsonify({"logged_in": True, "name": session["user_name"],
                        "email": session["user_email"]})
    return jsonify({"logged_in": False})


# ── Prediction (login required) ───────────────────────────────────
@app.route("/predict", methods=["POST"])
@login_required
def predict():
    try:
        name, age, gender, height, weight, activity, goal = validate_inputs(request.json or {})
    except ValidationError as err:
        return jsonify({"error": str(err)}), 400

    name = clean_name(name)                      # 'amit   PATIL' -> 'Amit Patil'
    score, calories = predict_health(age, gender, height, weight, activity)
    person = Person(name, age, gender, height, weight, activity)
    plan = make_plan(goal, person, calories).summary()

    bmi = person.bmi
    category = bmi_category(bmi)
    bmr = calc_bmr(age, gender, height, weight)
    water = round(weight * 0.033, 1)
    tips = health_tips(bmi, activity, goal, water)
    email = session["user_email"]

    storage.save_record({"name": name, "age": age, "gender": gender, "height": height,
                         "weight": weight, "activity": activity, "goal": goal,
                         "bmi": bmi, "score": score, "calories": calories, "user": email})
    report = save_report(email, {"name": name, "bmi": bmi, "bmi_category": category,
                                 "health_score": score, "daily_calories": calories,
                                 "bmr": bmr, "goal_calories": plan["target_calories"],
                                 "water_litres": water, "advice": plan["advice"],
                                 "tips": "; ".join(tips)})
    return jsonify({"name": name, "score": score, "calories": calories,
                    "bmi": bmi, "category": category, "bmr": bmr, "water": water,
                    "plan": plan, "tips": tips, "report": report})


# ── Dashboard & Progress APIs ─────────────────────────────────────
@app.route("/api/dashboard")
@login_required
def api_dashboard():
    user = session["user_email"]               # each user sees only his/her own data
    return jsonify({
        "latest": storage.latest_metrics(user),
        "stats": storage.stats(user),
        "recent": storage.entries(user, 5)[::-1],
        "model_r2": metrics,
    })


@app.route("/api/progress")
@login_required
def api_progress():
    user = session["user_email"]
    return jsonify({"months": storage.monthly_progress(user),
                    "entries": storage.entries(user)})


# ── History, reports and CSV export (login required) ──────────────
@app.route("/api/history")
@login_required
def api_history():
    return jsonify(history_data(session["user_email"]))


@app.route("/history.csv")
@login_required
def history_csv():
    return Response(records_csv(session["user_email"]), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=my_health_records.csv"})


@app.route("/reports/<path:filename>")
@login_required
def download_report(filename):
    if not is_report_of(session["user_email"], filename):      # only your own reports
        abort(403)
    if not os.path.isfile(report_path(filename)):
        abort(404)
    return send_file(report_path(filename), as_attachment=True)


# ── Charts ────────────────────────────────────────────────────────
@app.route("/chart/dashboard.png")
@login_required
def chart_dashboard():
    return Response(charts.dashboard_chart(session["user_email"]), mimetype="image/png")


@app.route("/chart/progress.png")
@login_required
def chart_progress_all():
    return Response(charts.progress_chart_all(session["user_email"]), mimetype="image/png")


@app.route("/chart/<metric>.png")
@login_required
def chart_progress_metric(metric):
    if metric not in ("bmi", "score", "calories", "weight"):
        return Response("Invalid metric", status=400)
    return Response(charts.progress_chart_metric(metric, session["user_email"]), mimetype="image/png")


@app.route("/chart.png")
def chart():
    return Response(charts.history_chart(session.get("user_email", "__none__")), mimetype="image/png")


@app.route("/stats")
def stats():
    return jsonify({"records": storage.stats(), "model_r2": metrics})


if __name__ == "__main__":
    app.run(debug=True)
