"""Regex validation, custom exception and health formulas."""
import re

class ValidationError(Exception):
    """Raised when user input is invalid."""

NAME_RE = re.compile(r"[A-Za-z][A-Za-z .'-]{1,29}")
GENDERS = ("male", "female")
ACTIVITIES = ("sedentary", "light", "moderate", "very", "extra")
GOALS = ("lose", "maintain", "gain")

def validate_name(name):
    name = str(name).strip()
    if not NAME_RE.fullmatch(name):
        raise ValidationError("Name must be 2-30 letters (spaces . ' - allowed).")
    return name

def validate_inputs(d):
    """Return cleaned values or raise ValidationError."""
    try:
        age, height, weight = int(d["age"]), float(d["height"]), float(d["weight"])
    except (KeyError, ValueError, TypeError):
        raise ValidationError("Age, height and weight must be numbers.")
    if not (10 <= age <= 100 and 100 <= height <= 250 and 25 <= weight <= 300):
        raise ValidationError("Age, height or weight is out of range.")
    gender, activity, goal = d.get("gender"), d.get("activity"), d.get("goal", "maintain")
    if gender not in GENDERS or activity not in ACTIVITIES or goal not in GOALS:
        raise ValidationError("Invalid gender, activity or goal.")
    return validate_name(d.get("name", "")), age, gender, height, weight, activity, goal

def calc_bmi(height_cm, weight_kg):
    return round(weight_kg / (height_cm / 100) ** 2, 1)

def calc_bmr(age, gender, height_cm, weight_kg):
    base = 10 * weight_kg + 6.25 * height_cm - 5 * age
    return round(base + (5 if gender == "male" else -161))
