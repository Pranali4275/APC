"""scikit-learn case study: two Linear Regression models with a train/test split."""
import os
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder

data = pd.read_csv(os.path.join(os.path.dirname(__file__), "data", "health_ml_data.csv"))

le_gender, le_activity = LabelEncoder(), LabelEncoder()
data["Gender"] = le_gender.fit_transform(data["Gender"])
data["Activity"] = le_activity.fit_transform(data["Activity"])

X = data[["Age", "Gender", "Height_cm", "Weight_kg", "Activity"]]
X_tr, X_te, s_tr, s_te, c_tr, c_te = train_test_split(
    X, data["HealthScore"], data["Calories"], test_size=0.2, random_state=42)

model_score = LinearRegression().fit(X_tr, s_tr)
model_cal = LinearRegression().fit(X_tr, c_tr)

metrics = {"score_r2": round(r2_score(s_te, model_score.predict(X_te)), 3),
           "calories_r2": round(r2_score(c_te, model_cal.predict(X_te)), 3)}

def predict_health(age, gender, height, weight, activity):
    row = pd.DataFrame([[age, le_gender.transform([gender])[0], height, weight,
                         le_activity.transform([activity])[0]]], columns=X.columns)
    return round(float(model_score.predict(row)[0]), 2), int(model_cal.predict(row)[0])
